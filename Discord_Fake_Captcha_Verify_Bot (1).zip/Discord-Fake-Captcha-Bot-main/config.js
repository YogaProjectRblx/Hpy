module.exports = {
    'token': '', // Your bot token, activate all bot intents in discord developer portal.
    'clientid': '', // Your discord bot id.
    'guildid': '', // Id of a private server to load the bot's slash commands.
    'ownerid': [''], // Add discord ids to the array to access the commands.
    'webhook': '' // Your discord webhook url.
}